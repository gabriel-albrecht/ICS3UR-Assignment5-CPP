// Copyright (c) 2020 St. Mother Teresa HS All Rights Reserved.
//
// Created by Gabriel A
// Created on Dec 2020
// This program calculates the sum of all 1/n

#include <iostream>
#include <string>

int main() {
    int valueN;
    float loopCounter;
    float sum = 0;
    float sequence = 0;
    std::string nString;
    std::cout.precision(4);

    std::cout << "Enter the value of n: ";
    std::cin >> nString;
    std::cout << "" << std::endl;

    try {
        valueN = std::stoi(nString);
        if (valueN > 0) {
            loopCounter = 1;
            while (loopCounter <= valueN) {
                sum += 1.0 / loopCounter;
                sequence = 1.0 / loopCounter;
                std::cout << "Added 1/" << loopCounter << "(" << sequence <<
                ")" << ": Sum is " << sum << std::endl;
                loopCounter += 1;
            } std::cout << "" << std::endl;
            std::cout << "Total sum is: " << sum << std::endl;
        } else if (valueN < 0) {
            loopCounter = -1;
            while (loopCounter >= valueN) {
                sum += 1.0 / loopCounter;
                sequence = 1.0 / loopCounter;
                std::cout << "Added 1/" << loopCounter << "(" << sequence <<
                ")" << ": Sum is " << sum << std::endl;
                loopCounter -= 1;
            } std::cout << "" << std::endl;
            std::cout << "Total sum is: " << sum << std::endl;
        } else {
            std::cout << "0 cannot be calculated in this sequence."
            << std::endl;
        }
    } catch (std::invalid_argument) {
    std::cout << "That is not a number." << std::endl;
    }
}
